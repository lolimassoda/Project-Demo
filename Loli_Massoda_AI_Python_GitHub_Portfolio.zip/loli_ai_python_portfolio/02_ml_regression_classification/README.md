# Regression and Classification Workflows

Two compact scikit-learn pipelines:
1. Regression on a synthetic housing-style dataset
2. Classification on the built-in breast cancer dataset

The project demonstrates preprocessing, train/test splitting, model fitting, evaluation, and reproducibility.

## Run
```bash
pip install -r requirements.txt
python train_models.py
```
