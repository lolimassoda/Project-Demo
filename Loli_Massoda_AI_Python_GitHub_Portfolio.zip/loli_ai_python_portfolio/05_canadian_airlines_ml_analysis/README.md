# Canadian Airlines Delay Classification

A complete Python workflow that predicts whether a flight will be delayed by at least 15 minutes.

## Includes
- synthetic Canadian-airline-style data generation
- preprocessing for numeric and categorical variables
- logistic regression pipeline
- accuracy, ROC-AUC, and classification report
- saved prediction sample

## Run
```bash
pip install -r requirements.txt
python generate_data.py
python airline_model.py
```

The dataset is synthetic and contains no real passenger information.
