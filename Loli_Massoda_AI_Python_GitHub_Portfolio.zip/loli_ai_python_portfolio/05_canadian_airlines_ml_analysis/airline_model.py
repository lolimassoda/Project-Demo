from __future__ import annotations
import json
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

RANDOM_STATE = 42

def main() -> None:
    df = pd.read_csv("canadian_airlines_synthetic.csv")
    X = df.drop(columns="delayed_15min")
    y = df["delayed_15min"]

    categorical = ["origin", "destination", "airline"]
    numeric = ["distance_km", "scheduled_hour", "weather_severity"]

    preprocess = ColumnTransformer([
        ("cat", Pipeline([
            ("impute", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore"))
        ]), categorical),
        ("num", Pipeline([
            ("impute", SimpleImputer(strategy="median")),
            ("scale", StandardScaler())
        ]), numeric),
    ])

    model = Pipeline([
        ("preprocess", preprocess),
        ("classifier", LogisticRegression(max_iter=2000))
    ])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE
    )
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    prob = model.predict_proba(X_test)[:, 1]

    metrics = {
        "accuracy": accuracy_score(y_test, pred),
        "roc_auc": roc_auc_score(y_test, prob),
        "classification_report": classification_report(y_test, pred, output_dict=True)
    }
    with open("airline_metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)

    sample = X_test.copy()
    sample["actual"] = y_test
    sample["predicted"] = pred
    sample["delay_probability"] = prob
    sample.head(50).to_csv("prediction_sample.csv", index=False)

    print(json.dumps({"accuracy": metrics["accuracy"], "roc_auc": metrics["roc_auc"]}, indent=2))

if __name__ == "__main__":
    main()
