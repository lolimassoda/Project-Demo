import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
n = 1200
airports = ["YYZ", "YVR", "YUL", "YYC", "YOW"]
airlines = ["Air Canada", "WestJet", "Porter"]
df = pd.DataFrame({
    "origin": rng.choice(airports, n),
    "destination": rng.choice(airports, n),
    "airline": rng.choice(airlines, n),
    "distance_km": rng.integers(300, 4200, n),
    "scheduled_hour": rng.integers(5, 23, n),
    "weather_severity": rng.integers(0, 4, n),
})
logit = -2.2 + 0.00025*df["distance_km"] + 0.38*df["weather_severity"] + 0.04*(df["scheduled_hour"]-12).clip(lower=0)
prob = 1/(1+np.exp(-logit))
df["delayed_15min"] = rng.binomial(1, prob)
df.to_csv("canadian_airlines_synthetic.csv", index=False)
print(df.head())
