# Database and Data-Warehouse Design

A Python + SQLite portfolio project that:
- creates a normalized operational flight database
- loads sample records
- builds a star-schema analytics warehouse
- runs summary queries by airline and route

SQLite is used so the project runs locally without a database server. The SQL concepts transfer directly to MySQL.

## Run
```bash
python build_databases.py
```
