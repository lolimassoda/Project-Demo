# Loli Massoda — AI & Python Portfolio Projects

This repository pack contains six independent, GitHub-ready Python projects:

1. LLM Output Evaluator
2. Regression and Classification Workflows
3. Automated Data Quality Validator
4. Two-Way ANOVA City Analysis
5. Canadian Airlines Delay Classification
6. Database and Data-Warehouse Design

## Important
These are newly created portfolio implementations based on the skills and project themes described in the resume. They should be presented as independent portfolio projects, not as exact copies of graded coursework unless they genuinely match work completed in class.

Each folder has its own README and requirements file.
