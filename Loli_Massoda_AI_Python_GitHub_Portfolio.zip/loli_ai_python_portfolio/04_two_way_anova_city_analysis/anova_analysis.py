import pandas as pd
import statsmodels.api as sm
from statsmodels.formula.api import ols

def main() -> None:
    df = pd.read_csv("city_program_scores.csv")
    model = ols("score ~ C(city) * C(program)", data=df).fit()
    table = sm.stats.anova_lm(model, typ=2)
    table.to_csv("anova_results.csv")
    print(table)

if __name__ == "__main__":
    main()
