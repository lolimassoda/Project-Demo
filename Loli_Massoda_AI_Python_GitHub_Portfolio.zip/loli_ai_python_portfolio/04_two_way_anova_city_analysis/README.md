# Two-Way ANOVA: City and Program Analysis

A statsmodels project testing:
- the effect of city
- the effect of program type
- the city × program interaction

The included dataset is synthetic and designed for portfolio demonstration.

## Run
```bash
pip install -r requirements.txt
python anova_analysis.py
```
