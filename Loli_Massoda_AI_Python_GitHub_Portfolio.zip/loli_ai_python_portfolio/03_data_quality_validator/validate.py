from __future__ import annotations
import re
import pandas as pd

VALID_STATUS = {"active", "inactive"}
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

def validate(df: pd.DataFrame) -> pd.DataFrame:
    issues = []
    for idx, row in df.iterrows():
        if row.isna().any():
            issues.append((idx, "missing_value", "One or more fields are missing"))
        if not (0 <= float(row["age"]) <= 120):
            issues.append((idx, "invalid_age", f"Age {row['age']} is outside 0–120"))
        if row["status"] not in VALID_STATUS:
            issues.append((idx, "invalid_status", f"Unexpected status: {row['status']}"))
        if not EMAIL_RE.match(str(row["email"])):
            issues.append((idx, "invalid_email", f"Malformed email: {row['email']}"))

    duplicate_mask = df.duplicated(keep=False)
    for idx in df.index[duplicate_mask]:
        issues.append((idx, "duplicate_row", "Row duplicates another record"))

    return pd.DataFrame(issues, columns=["row_index", "issue_type", "details"])

def main() -> None:
    df = pd.read_csv("sample_customers.csv")
    report = validate(df)
    report.to_csv("data_quality_report.csv", index=False)
    print(report.to_string(index=False))

if __name__ == "__main__":
    main()
