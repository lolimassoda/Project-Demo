# Automated Data Quality Validator

A reusable pandas-based validator that detects:
- missing values
- duplicate rows
- invalid numeric ranges
- invalid categories
- malformed email values

## Run
```bash
pip install -r requirements.txt
python validate.py
```
