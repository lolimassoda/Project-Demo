# LLM Output Evaluator

A Python project for comparing multiple language-model responses against a reusable quality rubric.

## Features
- Scores outputs for relevance, coherence, factual consistency, tone, naturalness, and instruction alignment
- Supports weighted scoring
- Produces a ranked CSV report
- Includes a transparent human-in-the-loop workflow

## Run
```bash
pip install -r requirements.txt
python evaluator.py
```

## Portfolio note
This is an independent portfolio implementation inspired by practical LLM evaluation workflows. It does not call a paid LLM API and can be extended with OpenAI, Anthropic, or local-model APIs.
