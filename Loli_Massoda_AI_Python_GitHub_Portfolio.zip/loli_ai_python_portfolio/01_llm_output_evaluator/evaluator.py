from __future__ import annotations
import json
from pathlib import Path
import pandas as pd

CRITERIA = {
    "relevance": 0.20,
    "coherence": 0.15,
    "factual_consistency": 0.20,
    "tone": 0.10,
    "naturalness": 0.15,
    "instruction_alignment": 0.20,
}

def score_response(text: str, instruction: str) -> dict[str, float]:
    """Transparent heuristic baseline. Replace or supplement with human ratings."""
    words = text.split()
    lower = text.lower()

    scores = {
        "relevance": 5.0 if "overfit" in lower else 2.0,
        "coherence": 5.0 if len(words) >= 15 and text.endswith((".", "!", "?")) else 3.0,
        "factual_consistency": 5.0 if any(k in lower for k in ["training", "new data", "unseen", "generalize"]) else 3.0,
        "tone": 5.0 if not any(k in lower for k in ["variance emerges", "empirical risk"]) else 2.0,
        "naturalness": 5.0 if len(words) <= 80 else 3.0,
        "instruction_alignment": 5.0 if len(words) <= 80 and any(k in lower for k in ["like", "beginner", "new data", "unseen"]) else 3.0,
    }
    return scores

def main() -> None:
    data = json.loads(Path("sample_responses.json").read_text())
    rows = []
    for item in data["responses"]:
        scores = score_response(item["text"], data["instruction"])
        weighted = sum(scores[k] * CRITERIA[k] for k in CRITERIA)
        rows.append({"response_id": item["id"], **scores, "weighted_score": round(weighted, 2), "text": item["text"]})

    result = pd.DataFrame(rows).sort_values("weighted_score", ascending=False)
    result.to_csv("evaluation_report.csv", index=False)
    print(result[["response_id", "weighted_score"]].to_string(index=False))

if __name__ == "__main__":
    main()
