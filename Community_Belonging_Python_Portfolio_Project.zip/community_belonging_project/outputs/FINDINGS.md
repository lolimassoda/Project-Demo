# Synthetic Community Belonging — Analysis Results

**Important: This is a portfolio demonstration using fabricated survey responses, NOT real Durham Region research.**

## Method
Generated sample responses (fixed random seed), checked missing values and valid score ranges, grouped participation frequency, calculated descriptive statistics, and produced three charts with Pandas and Matplotlib.

## Summary
- Synthetic responses: **160**; complete responses analyzed: **158**.
- Missing numeric entries across columns: **2** (removed rows with missing required values).
- Average belonging score: **6.17/10**.
- Correlation between social connection and belonging: **0.63** (descriptive association, not causation).

## Average belonging by monthly event participation

| Group | Responses | Mean belonging / 10 |
|---|---:|---:|
| 0–1 events | 65 | 5.83 |
| 2–3 events | 61 | 6.15 |
| 4+ events | 32 | 6.91 |

## Interpretation and limitations
The patterns reflect how this **synthetic dataset was generated**. They cannot support claims about real people, communities, the effectiveness of programs, or Durham Region. Group comparisons may be affected by other variables; correlation does not establish causation. No real participants were recruited, no personal data was collected, and no Research Ethics Board approval was sought or required for these invented records. A real study would need appropriate ethics review, sampling, consent, and privacy protections.

## Charts
- `belonging_by_participation.png` — group comparison
- `connection_vs_belonging.png` — association
- `belonging_distribution.png` — distribution
