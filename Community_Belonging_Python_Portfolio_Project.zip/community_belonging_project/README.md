# Community Belonging & Inclusion | Python Data Analysis Portfolio Project

> **Synthetic data only.** This is an independent learning/portfolio exercise inspired by questions about community participation and belonging. It is **not** affiliated with Durham College's *Future of Belonging* study and does **not** contain real Durham Region data.

## Research question
How do community event participation, service access, and social connections relate to a self-reported sense of belonging **in a simulated dataset**?

## Skills demonstrated
- Python, Pandas, Matplotlib
- Reproducible data generation and data cleaning
- Descriptive statistics, grouping, correlations
- Clear chart labels, accessible written summaries, methodological limitations

## Run
Python 3.10+ recommended.

```bash
pip install -r requirements.txt
python src/generate_data.py
python src/analyze.py
```

Outputs appear in `outputs/`: three PNG charts, `group_summary.csv`, and `FINDINGS.md`. The sample dataset is saved in `data/`.

## Data dictionary
| Field | Description |
|---|---|
| participant_id | Invented record ID (`SYN-###`) |
| age_group | Invented age bracket |
| community_events_per_month | Simulated event attendance count |
| service_access_score | Simulated score from 1 (low) to 10 (high) |
| social_connection_score | Simulated score from 1 to 10 |
| belonging_score | Simulated score from 1 to 10 |

The data generator intentionally leaves two numeric values blank to demonstrate missing-data handling. The relationships were programmed into the generator, so **patterns are illustrative and not empirical findings**.

## Ethical note
No participants, recruitment, surveys, or personal information were involved. A real human-participant study requires suitable consent, privacy practices, and ethics review before data collection.

## Portfolio use
After reviewing and understanding the code and findings, you can publish this repository on your own GitHub. Describe it accurately as a **synthetic-data portfolio project**.
