"""Generate fictional, reproducible sample responses. No real-person data."""
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
rng=np.random.default_rng(20261022)
n=160
age=rng.choice(['18–24','25–34','35–49','50–64','65+'],size=n,p=[.22,.25,.24,.19,.10])
events=np.clip(rng.poisson(2.0,n),0,8)
access=np.clip(np.rint(rng.normal(6.1,2.0,n)),1,10)
connection=np.clip(np.rint(3.0+.62*events+.24*access+rng.normal(0,1.6,n)),1,10)
belonging=np.clip(np.rint(1.5+.57*connection+.22*access+rng.normal(0,1.5,n)),1,10)
df=pd.DataFrame({'participant_id':[f'SYN-{i:03d}' for i in range(1,n+1)],'age_group':age,'community_events_per_month':events,'service_access_score':access.astype(float),'social_connection_score':connection.astype(float),'belonging_score':belonging.astype(float)})
# Two intentionally missing values to demonstrate cleaning.
df.loc[12,'service_access_score']=np.nan
df.loc[79,'belonging_score']=np.nan
path=ROOT/'data'/'synthetic_community_survey.csv';path.parent.mkdir(exist_ok=True)
df.to_csv(path,index=False)
print(f'Wrote {len(df)} fictional rows to {path}')
if __name__=='__main__': print('Synthetic dataset ready')
