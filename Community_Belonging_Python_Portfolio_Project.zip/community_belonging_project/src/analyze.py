"""Reproducible analysis of a SYNTHETIC community-belonging dataset."""
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data' / 'synthetic_community_survey.csv'
OUT = ROOT / 'outputs'
OUT.mkdir(exist_ok=True)

def main():
    df = pd.read_csv(DATA)
    required = {'participant_id','age_group','community_events_per_month','service_access_score','social_connection_score','belonging_score'}
    assert required.issubset(df.columns), 'Dataset is missing expected columns'
    assert df.participant_id.is_unique, 'Participant IDs must be unique'
    numeric = ['community_events_per_month','service_access_score','social_connection_score','belonging_score']
    for col in numeric:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    missing = df.isna().sum()
    clean = df.dropna(subset=numeric + ['age_group']).copy()
    assert clean[['service_access_score','social_connection_score','belonging_score']].apply(lambda s:s.between(1,10).all()).all()
    assert clean.community_events_per_month.ge(0).all()
    clean['participation_group'] = pd.cut(clean.community_events_per_month, bins=[-0.1,1,3,float('inf')], labels=['0–1 events','2–3 events','4+ events'])
    summary = clean.groupby('participation_group', observed=True).agg(n=('participant_id','size'),mean_belonging=('belonging_score','mean'),mean_service_access=('service_access_score','mean')).reset_index()
    summary.to_csv(OUT / 'group_summary.csv', index=False)
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    fig, ax = plt.subplots(figsize=(8,4.8))
    ax.bar(summary.participation_group.astype(str), summary.mean_belonging, color=['#9cb9c9','#538eaa','#17658c'])
    ax.set_ylim(0,10); ax.set_ylabel('Average belonging (1–10)'); ax.set_xlabel('Monthly community participation')
    ax.set_title('Average belonging by participation group', loc='left', weight='bold')
    for i,v in enumerate(summary.mean_belonging): ax.text(i,v+0.15,f'{v:.1f}',ha='center')
    fig.tight_layout(); fig.savefig(OUT/'belonging_by_participation.png',dpi=180); plt.close(fig)
    fig, ax = plt.subplots(figsize=(8,4.8))
    ax.scatter(clean.social_connection_score,clean.belonging_score,alpha=.6,color='#17658c',edgecolors='white',linewidths=.4)
    ax.set(xlim=(0.5,10.5),ylim=(0.5,10.5),xlabel='Social connection score (1–10)',ylabel='Belonging score (1–10)')
    ax.set_title('Social connection and belonging',loc='left',weight='bold')
    fig.tight_layout(); fig.savefig(OUT/'connection_vs_belonging.png',dpi=180); plt.close(fig)
    fig, ax = plt.subplots(figsize=(8,4.8))
    ax.hist(clean.belonging_score,bins=range(1,12),align='left',rwidth=.82,color='#538eaa')
    ax.set(xticks=range(1,11),xlabel='Belonging score (1–10)',ylabel='Number of responses')
    ax.set_title('Distribution of belonging scores',loc='left',weight='bold')
    fig.tight_layout(); fig.savefig(OUT/'belonging_distribution.png',dpi=180); plt.close(fig)
    corr = clean[['social_connection_score','belonging_score','service_access_score']].corr().loc['social_connection_score','belonging_score']
    report = f'''# Synthetic Community Belonging — Analysis Results\n\n**Important: This is a portfolio demonstration using fabricated survey responses, NOT real Durham Region research.**\n\n## Method\nGenerated sample responses (fixed random seed), checked missing values and valid score ranges, grouped participation frequency, calculated descriptive statistics, and produced three charts with Pandas and Matplotlib.\n\n## Summary\n- Synthetic responses: **{len(df)}**; complete responses analyzed: **{len(clean)}**.\n- Missing numeric entries across columns: **{int(missing[numeric].sum())}** (removed rows with missing required values).\n- Average belonging score: **{clean.belonging_score.mean():.2f}/10**.\n- Correlation between social connection and belonging: **{corr:.2f}** (descriptive association, not causation).\n\n## Average belonging by monthly event participation\n\n| Group | Responses | Mean belonging / 10 |\n|---|---:|---:|\n'''
    for _,r in summary.iterrows(): report += f'| {r.participation_group} | {int(r.n)} | {r.mean_belonging:.2f} |\n'
    report += '''\n## Interpretation and limitations\nThe patterns reflect how this **synthetic dataset was generated**. They cannot support claims about real people, communities, the effectiveness of programs, or Durham Region. Group comparisons may be affected by other variables; correlation does not establish causation. No real participants were recruited, no personal data was collected, and no Research Ethics Board approval was sought or required for these invented records. A real study would need appropriate ethics review, sampling, consent, and privacy protections.\n\n## Charts\n- `belonging_by_participation.png` — group comparison\n- `connection_vs_belonging.png` — association\n- `belonging_distribution.png` — distribution\n'''
    (OUT/'FINDINGS.md').write_text(report,encoding='utf-8')
    print(report)

if __name__=='__main__': main()
