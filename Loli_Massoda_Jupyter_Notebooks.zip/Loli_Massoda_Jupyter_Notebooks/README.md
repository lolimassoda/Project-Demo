# Jupyter Notebook Portfolio

This folder contains six standalone Jupyter notebooks:

1. LLM Output Evaluator
2. Regression and Classification
3. Data Quality Validator
4. Two-Way ANOVA
5. Canadian Airlines Machine Learning
6. Database and Data Warehouse

Open each `.ipynb` file in Jupyter Notebook, JupyterLab, VS Code, or Google Colab.

These are independent portfolio implementations. Describe them that way on GitHub unless they exactly match your completed coursework.
